using Avalonia.Controls;

namespace ColorMC.Gui.UI.Controls.GameExport;

public partial class Tab3Control : UserControl
{
    public Tab3Control()
    {
        InitializeComponent();
    }
}
