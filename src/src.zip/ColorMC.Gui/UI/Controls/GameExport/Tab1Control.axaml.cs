using Avalonia.Controls;

namespace ColorMC.Gui.UI.Controls.GameExport;

public partial class Tab1Control : UserControl
{
    public Tab1Control()
    {
        InitializeComponent();
    }
}
