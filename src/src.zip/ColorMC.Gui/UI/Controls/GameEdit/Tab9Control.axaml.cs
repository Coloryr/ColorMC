using Avalonia.Controls;

namespace ColorMC.Gui.UI.Controls.GameEdit;

public partial class Tab9Control : UserControl
{
    public Tab9Control()
    {
        InitializeComponent();
    }
}
