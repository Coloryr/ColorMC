using Avalonia.Controls;

namespace ColorMC.Gui.UI.Controls.NetFrp;

public partial class NetFrpTab2Control : UserControl
{
    public NetFrpTab2Control()
    {
        InitializeComponent();
    }
}
