using Avalonia.Controls;

namespace ColorMC.Gui.UI.Controls.NetFrp.Items;

public partial class NetFrpRemoteControl : UserControl
{
    public NetFrpRemoteControl()
    {
        InitializeComponent();
    }
}
