using Avalonia.Controls;

namespace ColorMC.Gui.UI.Controls.NetFrp.Items
{
    public partial class NetFrpLocalControl : UserControl
    {
        public NetFrpLocalControl()
        {
            InitializeComponent();
        }
    }
}
