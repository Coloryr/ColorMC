using Avalonia.Controls;

namespace ColorMC.Gui.UI.Controls.NetFrp;

public partial class NetFrpTab1Control : UserControl
{
    public NetFrpTab1Control()
    {
        InitializeComponent();
    }
}
