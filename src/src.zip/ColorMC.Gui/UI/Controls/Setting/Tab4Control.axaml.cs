using Avalonia.Controls;

namespace ColorMC.Gui.UI.Controls.Setting;

public partial class Tab4Control : UserControl
{

    public Tab4Control()
    {
        InitializeComponent();
    }
}
