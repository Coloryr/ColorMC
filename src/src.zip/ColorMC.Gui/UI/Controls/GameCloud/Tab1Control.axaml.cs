using Avalonia.Controls;

namespace ColorMC.Gui.UI.Controls.GameCloud;

public partial class Tab1Control : UserControl
{
    public Tab1Control()
    {
        InitializeComponent();
    }
}
