using Avalonia.Controls;

namespace ColorMC.Gui.UI.Controls.GameCloud;

public partial class Tab2Control : UserControl
{
    public Tab2Control()
    {
        InitializeComponent();
    }
}
