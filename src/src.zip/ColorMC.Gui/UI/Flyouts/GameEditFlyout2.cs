﻿using Avalonia.Controls;
using ColorMC.Core.Helpers;
using ColorMC.Gui.UI.Model.Items;
using ColorMC.Gui.UIBinding;

namespace ColorMC.Gui.UI.Flyouts;

public class GameEditFlyout2
{
    private readonly WorldModel _model;

    public GameEditFlyout2(Control con, WorldModel model)
    {
        _model = model;

        _ = new FlyoutsControl(new()
        {
            (App.Lang("Button.OpFile"), true, Button1_Click),
            (App.Lang("GameEditWindow.Flyouts2.Text5"), CheckHelpers.IsGameVersion120(_model.World.Game.Version), Button6_Click),
            (App.Lang("GameEditWindow.Flyouts2.Text1"), true, Button2_Click),
            (App.Lang("GameEditWindow.Flyouts2.Text4"), true, Button5_Click),
            (App.Lang("GameEditWindow.Flyouts2.Text3"), !_model.World.Broken, Button3_Click),
            (App.Lang("GameEditWindow.Flyouts2.Text2"), !_model.World.Broken, Button4_Click)
        }, con);
    }

    private void Button6_Click()
    {
        _model.Top.LaunchWorld(_model);
    }

    private void Button5_Click()
    {
        App.ShowConfigEdit(_model.World);
    }

    private void Button4_Click()
    {
        _model.Top.DeleteWorld(_model);
    }

    private void Button3_Click()
    {
        _model.Top.BackupWorld(_model);
    }

    private void Button2_Click()
    {
        _model.Top.Export(_model);
    }

    private void Button1_Click()
    {
        PathBinding.OpPath(_model.World);
    }
}
