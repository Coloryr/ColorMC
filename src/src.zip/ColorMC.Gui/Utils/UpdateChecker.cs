using ColorMC.Core;
using ColorMC.Core.Downloader;
using ColorMC.Core.Helpers;
using ColorMC.Core.Net;
using ColorMC.Core.Objs;
using ColorMC.Core.Utils;
using ColorMC.Gui.UIBinding;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.IO;
using System.Net.Http;
using System.Threading.Tasks;

namespace ColorMC.Gui.Utils;

/// <summary>
/// 启动器更新器
/// </summary>
public static class UpdateChecker
{
    //private const string url = $"http://localhost/colormc/{ColorMCCore.TopVersion}/";
    private const string s_baseUrl = $"https://mc1.coloryr.com:8081/update/";
    private const string s_checkUrl = $"{s_baseUrl}{ColorMCCore.TopVersion}/";

    public static readonly string[] WebSha1s = new string[4] { "", "", "", "" };
    public static readonly string[] Sha1s = new string[4] { "", "", "", "" };
    public static readonly string[] LocalPath = new string[4] { "", "", "", "" };

    public static void Init()
    {
        if (ColorMCGui.BaseSha1 == null)
            return;

        LocalPath[0] = Path.GetFullPath($"{ColorMCGui.RunDir}dll/ColorMC.Core.dll");
        LocalPath[1] = Path.GetFullPath($"{ColorMCGui.RunDir}dll/ColorMC.Core.pdb");
        LocalPath[2] = Path.GetFullPath($"{ColorMCGui.RunDir}dll/ColorMC.Gui.dll");
        LocalPath[3] = Path.GetFullPath($"{ColorMCGui.RunDir}dll/ColorMC.Gui.pdb");

        for (int a = 0; a < 4; a++)
        {
            if (File.Exists(LocalPath[a]))
            {
                using var file = PathHelper.OpenRead(LocalPath[a])!;
                Sha1s[a] = HashHelper.GenSha1(file);
            }
            else
            {
                Sha1s[a] = ColorMCGui.BaseSha1[a];
            }
        }
    }

    public static async void Check()
    {
        if (ColorMCGui.BaseSha1 == null)
            return;

        try
        {
            var req = new HttpRequestMessage(HttpMethod.Get, s_baseUrl + "index.json");
            req.Headers.Add("ColorMC", ColorMCCore.Version);
            var data = await BaseClient.DownloadClient.SendAsync(req);
            var obj = JObject.Parse(await data.Content.ReadAsStringAsync());
            if (obj == null)
            {
                App.UpdateCheckFail();
                return;
            }

            if (obj.TryGetValue("Version", out var temp)
                && ColorMCCore.TopVersion != temp.ToString())
            {
                var res = await App.HaveUpdate(obj["Text"]?.ToString());
                if (!res)
                {
                    BaseBinding.OpUrl("https://colormc.coloryr.com/");
                }
                return;
            }
            var data1 = await CheckOne();
            if (data1.Item1 == true)
            {
                var res = await App.HaveUpdate(data1.Item2!);
                if (!res)
                {
                    StartUpdate();
                }
            }
        }
        catch (Exception e)
        {
            App.UpdateCheckFail();
            Logs.Error(App.Lang("Gui.Error21"), e);
        }
    }

    public static async void StartUpdate()
    {
        if (ColorMCGui.BaseSha1 == null)
            return;

        var list = new List<DownloadItemObj>()
        {
            new()
            {
                Name = "ColorMC.Core.dll",
                SHA1 = WebSha1s[0],
                Url = $"{s_checkUrl}ColorMC.Core.dll",
                Local = $"{ColorMCGui.RunDir}dll/ColorMC.Core.dll",
                Overwrite = true,
                UseColorMCHead = true
            },
            new()
            {
                Name = "ColorMC.Core.pdb",
                SHA1 = WebSha1s[1],
                Url = $"{s_checkUrl}ColorMC.Core.pdb",
                Local = $"{ColorMCGui.RunDir}dll/ColorMC.Core.pdb",
                Overwrite = true,
                UseColorMCHead = true
            },
            new()
            {
                Name = "ColorMC.Gui.dll",
                SHA1 = WebSha1s[2],
                Url = $"{s_checkUrl}ColorMC.Gui.dll",
                Local = $"{ColorMCGui.RunDir}dll/ColorMC.Gui.dll",
                Overwrite = true,
                UseColorMCHead = true
            },
            new()
            {
                Name = "ColorMC.Gui.pdb",
                SHA1 = WebSha1s[3],
                Url = $"{s_checkUrl}ColorMC.Gui.pdb",
                Local = $"{ColorMCGui.RunDir}dll/ColorMC.Gui.pdb",
                Overwrite = true,
                UseColorMCHead = true
            }
        };

        var res = await DownloadManager.Start(list);
        if (res)
        {
            App.Reboot();
        }
        else
        {
            App.ShowError(App.Lang("Gui.Error22"), "");
        }
    }

    public static async Task<(bool?, string?)> CheckOne()
    {
        if (ColorMCGui.BaseSha1 == null)
            return (false, null);

        try
        {
            var req = new HttpRequestMessage(HttpMethod.Get, s_checkUrl + "sha1.json");
            req.Headers.Add("ColorMC", ColorMCCore.Version);
            var data = await BaseClient.DownloadClient.SendAsync(req);
            var obj = JObject.Parse(await data.Content.ReadAsStringAsync());
            if (obj == null)
            {
                App.ShowError(App.Lang("Gui.Error21"), "Json Error");
                return (false, null);
            }

            WebSha1s[0] = obj["core.dll"]!.ToString();
            WebSha1s[1] = obj["core.pdb"]!.ToString();
            WebSha1s[2] = obj["gui.dll"]!.ToString();
            WebSha1s[3] = obj["gui.pdb"]!.ToString();

            Logs.Info($"ColorMC.Core.dll:{Sha1s[0]} Web:{WebSha1s[0]}");
            Logs.Info($"ColorMC.Core.pdb:{Sha1s[1]} Web:{WebSha1s[1]}");
            Logs.Info($"ColorMC.Gui.dll:{Sha1s[2]} Web:{WebSha1s[2]}");
            Logs.Info($"ColorMC.Gui.pdb:{Sha1s[3]} Web:{WebSha1s[3]}");

            for (int a = 0; a < 4; a++)
            {
                if (WebSha1s[a] != Sha1s[a])
                {
                    obj.TryGetValue("text", out var data1);
                    return (true, data1?.ToString() ?? App.Lang("Gui.Info20"));
                }
            }

            return (false, null);
        }
        catch (Exception e)
        {
            App.ShowError(App.Lang("Gui.Error21"), e);
        }

        return (null, null);
    }
}
