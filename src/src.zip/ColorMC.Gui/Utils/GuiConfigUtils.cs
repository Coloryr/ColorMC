using ColorMC.Core.Config;
using ColorMC.Core.Helpers;
using ColorMC.Core.Utils;
using ColorMC.Gui.Objs;
using ColorMC.Gui.Utils.LaunchSetting;
using Newtonsoft.Json;
using System;
using System.IO;

namespace ColorMC.Gui.Utils;

/// <summary>
/// GUI配置文件
/// </summary>
public static class GuiConfigUtils
{
    public static GuiConfigObj Config { get; set; }

    private static string s_local;

    /// <summary>
    /// 初始化
    /// </summary>
    /// <param name="dir">运行路径</param>
    public static void Init(string dir)
    {
        s_local = dir + "gui.json";

        Load(s_local);
    }

    /// <summary>
    /// 加载配置文件
    /// </summary>
    /// <param name="local">路径</param>
    /// <param name="quit">加载失败是否退出</param>
    /// <returns>是否加载成功</returns>
    public static bool Load(string local, bool quit = false)
    {
        if (File.Exists(local))
        {
            try
            {
                Config = JsonConvert.DeserializeObject<GuiConfigObj>(File.ReadAllText(local))!;
            }
            catch (Exception e)
            {
                Logs.Error(App.Lang("Gui.Error17"), e);
            }

            if (Config == null)
            {
                if (quit)
                {
                    return false;
                }

                Config = MakeDefaultConfig();

                SaveNow();
                return true;
            }

            bool save = false;

            if (Config.ServerCustom == null)
            {
                Config.ServerCustom = MakeServerCustomConfig();
                save = true;
            }
            if (Config.Render == null
                || Config.Render.Windows == null
                || Config.Render.X11 == null)
            {
                Config.Render = MakeRenderConfig();
                save = true;
            }
            if (Config.ColorLight == null)
            {
                Config.ColorLight = MakeColorLightConfig();
                save = true;
            }
            if (Config.ColorDark == null)
            {
                Config.ColorDark = MakeColorDarkConfig();
                save = true;
            }
            if (Config.Live2D == null)
            {
                Config.Live2D = MakeLive2DConfig();
                save = true;
            }
            if (Config.Gui == null)
            {
                Config.Gui = MakeGuiSettingConfig();
                save = true;
            }
            if (Config.Style == null)
            {
                Config.Style = MakeStyleSettingConfig();
                save = true;
            }
            if (save)
            {
                Logs.Info(LanguageHelper.Get("Core.Config.Info2"));
                Save();
            }
        }
        else
        {
            Config = MakeDefaultConfig();

            SaveNow();
        }

        return true;
    }

    /// <summary>
    /// 立即保存
    /// </summary>
    public static void SaveNow()
    {
        Logs.Info(LanguageHelper.Get("Core.Config.Info2"));
        File.WriteAllText(s_local, JsonConvert.SerializeObject(Config));
    }

    /// <summary>
    /// 保存配置文件
    /// </summary>
    public static void Save()
    {
        ConfigSave.AddItem(new()
        {
            Name = "gui.json",
            Local = s_local,
            Obj = Config
        });
    }

    public static StyleSetting MakeStyleSettingConfig()
    {
        return new()
        {
            ButtonCornerRadius = 3,
            AmTime = 500
        };
    }

    public static Live2DSetting MakeLive2DConfig()
    {
        return new()
        {
            Width = 30,
            Height = 50
        };
    }

    public static Render MakeRenderConfig()
    {
        return new()
        {
            Windows = new()
            {
                ShouldRenderOnUIThread = null
            },
            X11 = new()
            {
                UseDBusMenu = null,
                UseDBusFilePicker = null,
                OverlayPopups = null
            }
        };
    }

    public static GuiConfigObj MakeDefaultConfig()
    {
        return new()
        {
            ColorMain = ColorSel.MainColorStr,
            ColorLight = MakeColorLightConfig(),
            ColorDark = MakeColorDarkConfig(),
            RGBS = 100,
            RGBV = 100,
            ServerCustom = MakeServerCustomConfig(),
            FontDefault = true,
            Render = MakeRenderConfig(),
            BackLimitValue = 50,
            EnableBG = true,
            BackImage = "https://api.cyrilstudio.top/bing/image.php",
            Live2D = MakeLive2DConfig(),
            Gui = MakeGuiSettingConfig(),
            Style = MakeStyleSettingConfig()
        };
    }

    public static ColorSetting MakeColorLightConfig()
    {
        return new()
        {
            ColorBack = ColorSel.BackLigthColorStr,
            ColorTranBack = ColorSel.Back1LigthColorStr,
            ColorFont1 = ColorSel.ButtonLightFontStr,
            ColorFont2 = ColorSel.FontLigthColorStr,
        };
    }

    public static ColorSetting MakeColorDarkConfig()
    {
        return new()
        {
            ColorBack = ColorSel.BackDarkColorStr,
            ColorTranBack = ColorSel.Back1DarkColorStr,
            ColorFont1 = ColorSel.ButtonDarkFontStr,
            ColorFont2 = ColorSel.FontDarkColorStr,
        };
    }

    public static ServerCustom MakeServerCustomConfig()
    {
        return new()
        {
            MotdColor = "White",
            MotdBackColor = "Black",
            Volume = 30
        };
    }

    public static MainWindowSetting MakeGuiSettingConfig()
    {
        return new()
        {

        };
    }
}