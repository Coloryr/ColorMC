﻿namespace ColorMC.Gui.Objs;

public record MenuObj
{
    public string Icon { get; set; }
    public string Text { get; set; }
}
