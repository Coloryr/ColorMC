﻿namespace ColorMC.Core.Objs.Minecraft;

public record ShaderpackObj
{
    public string Name { get; set; }
    public string Local { get; set; }
}
