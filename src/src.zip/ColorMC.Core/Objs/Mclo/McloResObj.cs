﻿namespace ColorMC.Core.Objs.Mclo;

public record McloResObj
{
    public bool success { get; set; }
    public string id { get; set; }
    public string url { get; set; }
    public string raw { get; set; }
}
