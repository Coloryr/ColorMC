﻿namespace ColorMC.Core.Objs.Minecraft;

public record UserPropertyObj
{
    public string name { get; set; }
    public string value { get; set; }
}
