namespace ColorMC.Core.Objs.Config;

public record ConfigSaveObj
{
    public string Name;
    public object Obj;
    public string Local;
}
