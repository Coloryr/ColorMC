﻿namespace ColorMC.Core.Objs.Loader;

public record NeoForgeVersionObj
{
    public string mcversion { get; set; }
    public string version { get; set; }
    public string rawVersion { get; set; }
}
