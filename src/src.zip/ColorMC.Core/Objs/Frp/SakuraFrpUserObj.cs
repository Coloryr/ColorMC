﻿namespace ColorMC.Core.Objs.Frp;

public record SakuraFrpUserObj
{
    public int id { get; set; }
    public string name { get; set; }
}
